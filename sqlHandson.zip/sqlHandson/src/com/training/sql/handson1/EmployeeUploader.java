package com.training.sql.handson1;
import java.util.*;

import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;

import java.sql.*;

public class EmployeeUploader {
private Connection con;
private PreparedStatement stm;
private Scanner sc;
private CallableStatement cstm;
EmployeeUploader(){
	sc=new Scanner(System.in);
	con=DataConnnect.getConnect();
}
public void storeDepaartment() throws SQLException{
	System.out.println("enter department details");
	System.out.println("enter howmany department you want to enter");
	int n=sc.nextInt();
	stm=con.prepareStatement("insert into department values(?,?,?,?)");
	for(int i=0;i<n;i++) {
		System.out.println("enter departmentid");
		stm.setInt(1, sc.nextInt());
		System.out.println("enter departmentname");
		stm.setString(2, sc.next());
		System.out.println("enter department head");
		stm.setString(3, sc.next());
		System.out.println("enter departmentdescription");
		stm.setString(4, sc.next());
		int result=stm.executeUpdate();
		if(result>0) {
			System.out.println("insert sucessffuly");
		}
		}
	
	}

public void storeemployeeDetaiils() throws SQLException, EmployeAlreadyExist,MySQLIntegrityConstraintViolationException {
	System.out.println("enter employee details");
	System.out.println("enter howmany employee you want to enter");
	int n=sc.nextInt();
	try {
		
	
	stm=con.prepareStatement("insert into employeetable values(?,?,?,?,?,?)");
	for(int i=0;i<n;i++) {
		System.out.println("enter employeeid");
		
			stm.setInt(1, sc.nextInt()); 		
		
		System.out.println("enter empname");
		stm.setString(2, sc.next());
		System.out.println("enter empaddress");
		stm.setString(3, sc.next());
		System.out.println("enter salary");
		stm.setInt(4, sc.nextInt());
		System.out.println("enter phno");
		stm.setInt(5, sc.nextInt());
		System.out.println("enter dept id");
		stm.setInt(6, sc.nextInt());
		
		int result=stm.executeUpdate();
		if(result>0) {
			System.out.println("insert sucessffuly");
		}
	}
	}catch(Exception e) {
		throw new EmployeAlreadyExist();
	}
	
	
}
public void calculatepf() throws SQLException {
	System.out.println("enter emp code whoch you want to calculate pf");
	int  code=sc.nextInt();
	cstm=con.prepareCall("{call calPF(?,?)}");
	cstm.setInt(1, code);
	cstm.registerOutParameter(2, Types.INTEGER);
	cstm.executeUpdate();
	//int empid=cstm.getInt(1);
	int pf=cstm.getInt(2);
//	System.out.println("emp idd"+empid);
	System.out.println("pf amount is"+pf);
}
public void retrivedata(int id) throws SQLException {
//stm=con.prepareStatement("select empid from employeetable where empid="+id+"");
stm=con.prepareStatement("select e.empid,e.empname,e.empaddress,e.empphno,d.departmentname,d.departmenthead from "
		+ "employeetable e  join department d on e.departmentid=d.departmentid where e.empid=?");
 
	stm.setInt(1, id);


//System.out.println("empid"+result.getInt(1));
	ResultSet result=stm.executeQuery();
while(result.next()) {
		System.out.println("eemp id"+result.getInt(1));
		System.out.println("empname"+result.getString(2));
		System.out.println("eemp address"+result.getString(3));
		System.out.println("empname"+result.getInt(4));
		System.out.println("department name"+result.getString(5));
		System.out.println("department head"+result.getString(6));
	
//}else {
	//System.out.println("not exits");
}
}
}
