package com.training.sql.handson1;

import java.sql.SQLException;

public class Main {
	public static void main(String args[]) throws EmployeAlreadyExist {
		EmployeeUploader e=new EmployeeUploader();
		try {
		//	e.storeDepaartment();
		e.storeemployeeDetaiils();
			//e.retrivedata(1);
			//e.calculatepf();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
		//	System.out.println(e1.getMessage());
			e1.getMessage();
		}
	}

}
