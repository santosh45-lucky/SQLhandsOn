package com.training.sql.handson1;

public class EmployeAlreadyExist extends Exception {
	public String getMessage(){
		return "you dont insert employee deatils employee already exist";	
		}
}
