package com.training.sql.handson1;
import java.sql.*;
public class DataConnnect {
	  private static Connection con;
	    private DataConnnect()
	    {
	        try
	        {
	            Class.forName("com.mysql.jdbc.Driver");
	            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/santosh","root","Santosh@123");
	            System.out.println("connection established");
	        }
	        catch(Exception e)
	        {
	            e.getMessage();
	        }
	    }
	    public static Connection getConnect()
	    {
	    	DataConnnect d=new DataConnnect();
	        return con;
	    }
	   public static void main(String args[]) {
		   getConnect();
	   }
}
