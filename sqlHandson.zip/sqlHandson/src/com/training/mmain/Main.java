package com.training.mmain;

import java.sql.SQLException;

import com.training.service.ItemService;
import com.traning.menu.Menu;

public class Main {
public static void main(String args[]) {
	Menu ob=new Menu();
	try {
		ob.displayMenu();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
