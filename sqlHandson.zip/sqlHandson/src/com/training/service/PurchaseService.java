package com.training.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.training.pojo.Purchase;
import com.traininng.dao.PurchaseDao;

public class PurchaseService {
	PurchaseDao purchasedao;
	List<Purchase> plist;
	Scanner sc;
	public PurchaseService(){
		purchasedao=new PurchaseDao();
		plist=new ArrayList<>();
		sc=new Scanner(System.in);
		
	}
	public void purchaseInsert() throws SQLException {
		System.out.println("enter howmany item you want to  store");
		int n=sc.nextInt();
		for(int i=0;i<n;i++) {
			Purchase p=new Purchase();
			System.out.println("enter tarnsaction id");
			p.setTransid(sc.nextInt());
			System.out.println("enter customer code");
			p.setPcustomrocde(sc.nextInt());
			System.out.println("enter item code");
			p.setPitemcode(sc.nextInt());
			System.out.println("enter item date");
			p.setPdate(sc.next());
			System.out.println("enter quantity");
			p.setPquantity(sc.nextInt());
			plist.add(p);
		}
		purchasedao.getpurchasedeatils(plist);
	}
}
