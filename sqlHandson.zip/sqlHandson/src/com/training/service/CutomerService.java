package com.training.service;
import java.sql.SQLException;
import java.util.*;

import com.training.pojo.Customer;
import com.traininng.dao.CustomerDao;
public class CutomerService {
Scanner sc;
List<Customer> clist;
CustomerDao customerdao;
public CutomerService(){
	sc=new Scanner(System.in);
	clist=new ArrayList<>();
	customerdao=new CustomerDao();
}
public void storeCustomerDeatils() throws SQLException {
	System.out.println("enter howmany customer you want to add");
	int n=sc.nextInt();
	for(int i=0;i<n;i++) {
		Customer c=new Customer();
		System.out.println("enter customer code");
		c.setCustomercode(sc.nextInt());
		System.out.println("enter customer name");
		c.setCustomername(sc.next());
		System.out.println("enter phno");
		c.setCustomerph(sc.nextInt());
		System.out.println("enter address");
		
		c.setCustomeraddress(sc.next());
		clist.add(c);
	}
	customerdao.storecustomerDetails(clist);
}

}

