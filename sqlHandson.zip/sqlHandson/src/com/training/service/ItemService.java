package com.training.service;
import java.sql.SQLException;
import java.util.*;
import com.training.pojo.*;
import com.traininng.dao.ItemDao;
public class ItemService {
	ItemDao itemdao;
List<Item> ilist;
Scanner sc;
public ItemService(){
	itemdao=new ItemDao();
	ilist=new ArrayList<>();
	sc=new Scanner(System.in);
	
}
public void itemInsert() throws SQLException {
	System.out.println("enter howmany item you want to  store");
	int n=sc.nextInt();
	for(int i=0;i<n;i++) {
		Item obi=new Item();
		System.out.println("enter item code");
		obi.setItemcode(sc.nextInt());
		System.out.println("enter item name");
		obi.setItemname(sc.next());
		System.out.println("enter item prrice");
		obi.setItemprice(sc.nextInt());
		System.out.println("enter item quantity");
		obi.setQuantity(sc.nextInt());
		ilist.add(obi);
	}
	itemdao.getitemdeatils(ilist);
}

}
