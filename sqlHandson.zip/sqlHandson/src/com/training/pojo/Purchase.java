package com.training.pojo;

public class Purchase {
private int transid;
private int pcustomrocde;
private int pitemcode;
private int pquantity;
private String pdate;
public int getTransid() {
	return transid;
}
public void setTransid(int transid) {
	this.transid = transid;
}
public int getPcustomrocde() {
	return pcustomrocde;
}
public void setPcustomrocde(int pcustomrocde) {
	this.pcustomrocde = pcustomrocde;
}
public int getPitemcode() {
	return pitemcode;
}
public void setPitemcode(int pitemcode) {
	this.pitemcode = pitemcode;
}
public int getPquantity() {
	return pquantity;
}
public void setPquantity(int pquantity) {
	this.pquantity = pquantity;
}
public String getPdate() {
	return pdate;
}
public void setPdate(String pdate) {
	this.pdate = pdate;
}

}
