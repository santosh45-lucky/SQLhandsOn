package com.training.pojo;

public class Customer {
private int customercode;
private String customername;
private int customerph;
private String customeraddress;
public int getCustomercode() {
	return customercode;
}
public void setCustomercode(int customercode) {
	this.customercode = customercode;
}
public String getCustomername() {
	return customername;
}
public void setCustomername(String customername) {
	this.customername = customername;
}
public int getCustomerph() {
	return customerph;
}
public void setCustomerph(int customerph) {
	this.customerph = customerph;
}
public String getCustomeraddress() {
	return customeraddress;
}
public void setCustomeraddress(String customeraddress) {
	this.customeraddress = customeraddress;
}

}
