package com.traning.menu;
import java.sql.SQLException;
import java.util.*;

import com.training.service.CutomerService;
import com.training.service.ItemService;
import com.training.service.PurchaseService;
import com.traininng.dao.CustomerDao;
import com.traininng.dao.ItemDao;
import com.traininng.dao.MyshopCalulate;
import com.traininng.dao.PurchaseDao;
public class Menu {
	Scanner sc;
	ItemService iservice;
	CutomerService cservice;
	PurchaseService pservice;
	CustomerDao cdao;
	ItemDao idao;
	PurchaseDao pdao;
	MyshopCalulate mob;
	public Menu(){
		sc=new Scanner(System.in);
		iservice=new ItemService();
		cservice=new CutomerService();
		pservice=new PurchaseService();
		idao=new ItemDao();
		cdao=new CustomerDao();
		pdao=new PurchaseDao();
		mob=new MyshopCalulate();	
	}
public void displayMenu() throws SQLException {
	String choice="y";
	while(choice.equals("y")) {
	System.out.println("1.insert item details");
	System.out.println("2.insert customer details");
	System.out.println("3.insert  purchase details");
	System.out.println("4.showing item details");
	System.out.println("5.showing customer deatils  by id");
	System.out.println("6.showing purchase details by id");
	System.out.println("7.calculate conseesion price");
	int ch=sc.nextInt();
	switch(ch) {
	case 1:
		iservice.itemInsert();
		break;
	case 2:
		cservice.storeCustomerDeatils();
		break;
	case 3:
		pservice.purchaseInsert();
		break;
	case 4:
		idao.showitemdeatils();
		break;
	case 5:
		cdao.customerDeatails();
		break;
	case 6:
		pdao.showpurchasedeatils();
		break;
	case 7:
		mob.calculateConsession("3");
	}
	System.out.println("do you eant to cointine");
	choice=sc.next();
}

}

}