package com.traininng.dao;
import java.sql.*;

import com.training.connect.DataConnnect;
public class MyshopCalulate {
Connection con;

private CallableStatement cstm;
public MyshopCalulate(){
	con=DataConnnect.getConnect();
	
}
public void calculateConsession(String code)throws SQLException {
	cstm=con.prepareCall("{call Concession_calculate1(?,?)}");
	cstm.setString(1, code);
	cstm.registerOutParameter(2, Types.INTEGER);
	cstm.executeUpdate();
	//String icode=cstm.getString(1);
	int cprice=cstm.getInt(2);
	//System.out.println("item code is"+icode);
	System.out.println("consession price"+cprice);
	
}
}
