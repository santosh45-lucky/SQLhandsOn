package com.traininng.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.training.connect.DataConnnect;
import com.training.pojo.Customer;
import com.training.pojo.Purchase;
import java.util.*;
public class PurchaseDao {
	private Connection con;
	PreparedStatement stmt;
	Scanner sc;
	public PurchaseDao(){
		con=DataConnnect.getConnect();
		sc=new Scanner(System.in);
	}
	public void getpurchasedeatils(List<Purchase> plist) throws SQLException {
		
		stmt=con.prepareStatement("insert into purchasetable values(?,?,?,?,?)");
		for(Purchase p:plist) {
			stmt.setInt(1, p.getTransid());
			stmt.setInt(2, p.getPcustomrocde());;
			stmt.setInt(3, p.getPitemcode());
			stmt.setString(4, p.getPdate());
			stmt.setInt(5, p.getPquantity());;
			int res=stmt.executeUpdate();
			if(res>0) {
				System.out.println("data inserted");
			}
		}
		
	}
public void showpurchasedeatils() throws SQLException {
	System.out.println("enter customer id which you want to show deatils");
	int id=sc.nextInt();
	System.out.println("deatils are");
stmt=con.prepareStatement("select c.customername,i.itemname,p.quantity from customertable c join itemtable i join purchasetable p on c.customercode=p.customercode and i.itemcode=p.itemcode where p.customercode="+id+"");
//stmt.setInt(1, id);
ResultSet res=stmt.executeQuery();
while(res.next()) {
	//System.out.println("transt id"+res.getInt(1));
	System.out.println("customer name"+res.getString(1));
	System.out.println("item name"+res.getString(2));
	//System.out.println("date"+res.getString(4));
	System.out.println("quantity"+res.getInt(3));
}

}

}
