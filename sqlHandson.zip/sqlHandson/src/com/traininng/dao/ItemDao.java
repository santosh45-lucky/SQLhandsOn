package com.traininng.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.training.connect.DataConnnect;
import com.training.pojo.Item;

public class ItemDao {
	Connection con;
	PreparedStatement stmt;
	Scanner sc;
	public ItemDao(){
		con=DataConnnect.getConnect();
		sc=new Scanner(System.in);
	}
	public void getitemdeatils(List<Item> ilist) throws SQLException {
		// TODO Auto-generated method stub
		
		stmt=con.prepareStatement("insert into itemtable values(?,?,?,?)");
		for(Item i:ilist) {
		stmt.setInt(1, i.getItemcode());
		stmt.setString(2, i.getItemname());
		stmt.setInt(3, i.getItemprice());
		stmt.setInt(4, i.getQuantity());
		int result=stmt.executeUpdate();
		if(result>0) {
			System.out.println("item data inserted");
		}
		}

	}
	public  void showitemdeatils() throws SQLException{
		System.out.println("item deatils are");
		stmt=con.prepareStatement("select * from itemtable");
		ResultSet res=stmt.executeQuery();
		if(res != null) {
		while(res.next()) {
			System.out.println("item id"+res.getInt(1));
			System.out.println("item name"+res.getString(2));
			System.out.println("item price"+res.getInt(3));
			System.out.println("item quantity"+res.getInt(4));
		}
		}else {
			System.out.println("no data availabale");
		}
	}
}