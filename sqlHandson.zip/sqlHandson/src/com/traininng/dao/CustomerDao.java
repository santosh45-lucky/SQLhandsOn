package com.traininng.dao;

import java.util.List;
import java.util.*;
import com.training.connect.DataConnnect;
import com.training.pojo.Customer;
import java.sql.*;
public class CustomerDao {
private Connection con;
PreparedStatement stmt;
Scanner sc;
public CustomerDao(){
	con=DataConnnect.getConnect();
	sc=new Scanner(System.in);
}
	public void storecustomerDetails(List<Customer> clist) throws SQLException {
stmt=con.prepareStatement("insert into customertable values(?,?,?,?)");
for(Customer c:clist) {
	stmt.setInt(1, c.getCustomercode());
	stmt.setString(2, c.getCustomername());
	stmt.setInt(3, c.getCustomerph());
	stmt.setString(4, c.getCustomeraddress());
	int res=stmt.executeUpdate();
	if(res>0) {
		System.out.println("data inserted");
	}
}
		
	}

public void customerDeatails() throws SQLException {
	System.out.println("enter customer id which you want to show deatils");
	int id=sc.nextInt();
	System.out.println("deatils are");
stmt=con.prepareStatement("select * from customertable where customercode="+id+"");
//stmt.setInt(1, id);
ResultSet res=stmt.executeQuery();
if(res != null) {
while(res.next()) {
	System.out.println("customer id"+res.getInt(1));
	System.out.println("customer name"+res.getString(2));
	System.out.println("customer phhone"+res.getInt(3));
	System.out.println("customer address"+res.getString(4));
}
}else {
	System.out.println("no data avaiable");
}
}
}
